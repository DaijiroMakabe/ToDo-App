<a href="<?php echo e(route('password.reset', ['token' => $token])); ?>">
  パスワード再設定リンク
</a><?php /**PATH /var/www/html/sample_app/resources/views/mail/password-reset.blade.php ENDPATH**/ ?>